﻿using Microsoft.EntityFrameworkCore;
using NorthwindDemo.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NorthwindDemo.Pages
{
    /// <summary>
    /// Interaction logic for Customers.xaml
    /// </summary>
    public partial class Customers : Page
    {
        NorthwindContext _context = new NorthwindContext();
        CollectionViewSource customerViewSource = new CollectionViewSource();

        public Customers()
        {
            InitializeComponent();

            //Tie the markup viewsource object to the code viewsource object
            customerViewSource = (CollectionViewSource)FindResource(nameof(customerViewSource));

            _context.Customers.Load();  //Use the dbContext to tell EF to load the data we'll use on this page
            
            //Set the viewsource data source to use the customers data collection
            customerViewSource.Source = _context.Customers.Local.ToObservableCollection();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            _context.SaveChanges();

        }
    }
}
